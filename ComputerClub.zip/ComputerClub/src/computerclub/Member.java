/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computerclub;

/**
 *
 * @author My PC
 */

public class Member {
    String name;
    String id;
    String batch;
    String dept;
    String mail;
   

    public Member(String name, String id, String batch, String dept,String mail) {
        this.name = name;
        this.id = id;
        this.batch = batch;
        this.dept = dept;
        this.mail=mail;
    
    }
    
    public String getId(){
        return id;
        
    }
    
    public String getName(){
        return name;
        
    }
    public String getBatch(){
        return batch;
        
    }
    
    public String getDept(){
        return dept;
        
    }
    public String getMail(){
        return mail;
        
    }
    
        
}
    
    
    
    
